import xbmcaddon

MainBase = 'http://pastebin.com/tfgUtRyJ'
MainBase = 'http://pastebin.com/raw/nzHKCQA0'
MainBase = 'http://pastebin.com/raw/HDyat5Fr'
MainBase = 'http://pastebin.com/raw/KELdKEzH'
MainBase = 'http://pastebin.com/raw/BzJ3eKDi'
MainBase = 'http://pastebin.com/raw/ibrtP2v1'
addon = xbmcaddon.Addon('script.module.vod.tvsupertuga.addon')