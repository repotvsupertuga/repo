# plugin.video.arenavisionezy
ArenaVision add-on para Kodi
Desarrollado por Wazzu

Este addon sirve como interfaz para la agenda de ArenaVision.in<br>
El addon se actualiza cada hora con los eventos de ArenaVision y permite la reproducción vía Acestream o Sopcast.<br>
Es imprescindible tener instalado y configurado el addon Plexus<br>
